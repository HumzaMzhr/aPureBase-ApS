export type PreflightStatus='READY'|'MISSING_CREDENTIAL'|'MODEL_UNAVAILABLE'|'MIC_PERMISSION_REQUIRED'|'TRANSPORT_ERROR'|'UNKNOWN_ERROR';
/** READY is an engineering preflight status, never proof of actual microphone accuracy. */
export function preflightStatus(input:{configured?:boolean;modelAvailable?:boolean;permission?:'granted'|'denied'|'prompt';transport?:'ready'|'error'|'unknown';failure?:string}):PreflightStatus {
 if(input.configured===false)return'MISSING_CREDENTIAL';
 if(input.modelAvailable===false)return'MODEL_UNAVAILABLE';
 if(input.permission!=='granted')return'MIC_PERMISSION_REQUIRED';
 if(input.transport==='error')return'TRANSPORT_ERROR';
 return input.configured===true&&input.modelAvailable===true&&input.transport==='ready'&&!input.failure?'READY':'UNKNOWN_ERROR';
}
