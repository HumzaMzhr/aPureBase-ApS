import {writeFile,readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const {technicalAudioQA}=await import(pathToFileURL(process.cwd()+'/scripts/stage20c32-hardening-qa.ts').href);
const q=await technicalAudioQA();assert.equal(q.totalAvailableWavs,286);assert.equal(q.approvedInventory.passed,49);assert.equal(q.outsideConsentInventory.rows.length,237);assert.equal(q.outsideConsentInventory.unrecognizedStructuralFailures,0);assert.equal(q.outsideConsentInventory.payloadAlignmentFailures,0);assert.equal(q.outsideConsentInventory.filesWithRawClipping,0);
const unknown=q.outsideConsentInventory.rows.filter((r:any)=>r.durationStatus==='UNKNOWN');assert.equal(unknown.length,12);assert(unknown.every((r:any)=>r.durationSeconds===null&&r.truncated===null&&r.streamingHeader));assert(q.approvedInventory.rows.every((r:any)=>r.gain.clippingEvents===0&&r.rawClipping===0));assert.equal(q.approvedInventory.rows.reduce((s:number,r:any)=>s+r.gain.peakProtectionEvents,0),4);
const original=JSON.parse(await readFile('docs/stage-2.0c-3.2-hardening-2-audio-qa.json','utf8'));assert.deepEqual(q,original);
await writeFile('/tmp/c32h2-precommit/audio-qa.json',JSON.stringify(q,null,2)+'\n');console.log(JSON.stringify({status:'PASS',total:286,protected:49,anonymous:237,unknownDurations:12,clipping:0,peakProtection:4,exactlyMatchesPriorQA:true}));
