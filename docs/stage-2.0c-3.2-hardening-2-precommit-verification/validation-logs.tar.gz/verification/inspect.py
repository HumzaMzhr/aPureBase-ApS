import subprocess,json,re,hashlib,tarfile,io
from pathlib import Path
b=json.loads(Path('/tmp/c32h2-precommit/before.json').read_text()); paths=[r['path'] for r in b['records']];tracked=set(subprocess.check_output(['git','ls-files','-z']).decode().split('\0'));untracked=[p for p in paths if p not in tracked]
secret=[];fixture=[];white=[];binary=[];archiveMembers=0;scanned=0
pat=re.compile(rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}|\bAKIA[A-Z0-9]{16}\b|-----BEGIN [A-Z ]*PRIVATE KEY-----|\bBearer\s+[A-Za-z0-9._-]{12,}')
def scan(name,data):
 global scanned,archiveMembers
 scanned+=1
 for m in pat.finditer(data):
  out={'path':name,'line':data[:m.start()].count(b'\n')+1,'value':'REDACTED'}
  if m.group()==b'Bearer secret-token-123456':out['reason']='Known unchanged synthetic secret-rejection test fixture';fixture.append(out)
  else:secret.append(out)
 if name.endswith('.tar.gz'):
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as a:
   for r in a:
    archiveMembers+=1
    if r.isfile():scan(name+'!'+r.name,a.extractfile(r).read())
for p in untracked:
 data=Path(p).read_bytes();scan(p,data)
 try:data.decode('utf8')
 except UnicodeDecodeError:binary.append({'path':p,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});continue
 q=subprocess.run(['git','diff','--no-index','--check','/dev/null',p],capture_output=True,text=True)
 if q.stdout.strip() or q.stderr.strip():white.append({'path':p,'output':q.stdout+q.stderr})
unchanged=all(hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'] for r in b['records'])
assert unchanged,'Unexpected candidate drift';assert not secret,secret;assert not white,white
proof=json.loads(Path('/tmp/c32h2-validation-pM86p1/source-proof.json').read_text());assert all(hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'] for r in proof['sourceProof'])
index=json.loads(Path('docs/stage-2.0c-3.2-hardening-2-acceptance-index.json').read_text());qa=json.loads(Path('/tmp/c32h2-precommit/audio-qa.json').read_text());hashes={r['hash'] for r in qa['approvedInventory']['rows']}
assert set(index['categories'])=={'STILL_VALID','RETEST_REQUIRED','SUPERSEDED','NOT_YET_TESTED'}
for row in index['categories']['STILL_VALID']+index['categories']['RETEST_REQUIRED']:assert row['assetHash'] in hashes
for row in index['categories']['SUPERSEDED']:assert row['predecessor']['assetHash'] in hashes and row['replacement']['assetHash'] in hashes and row['predecessor']['assetHash']!=row['replacement']['assetHash']
assert all(Path(r['current']).exists() for r in index['currentDocuments']);assert Path(index['currentHumanGuide']).exists()
r={'status':'PASS','candidateFiles':len(paths),'untrackedFiles':len(untracked),'trackedChanges':subprocess.check_output(['git','diff','--name-status']).decode(),'preverificationFilesUnchanged':unchanged,'sourceProofFiles':len(proof['sourceProof']),'untrackedTextAndArchiveMembersScanned':scanned,'archiveMembersInspected':archiveMembers,'secretFindings':secret,'knownNonSecretFixtures':fixture,'whitespaceFindings':white,'binaries':binary,'acceptanceIndex':{k:len(v) for k,v in index['categories'].items()},'envFilesIntroduced':[p for p in untracked if Path(p).name.startswith('.env')],'inspectionLimit':'Pattern/structure/manual inspection, not a proof against arbitrary steganography. Existing archives inspected recursively; private ignored recordings are outside the publishing candidate.'}
Path('/tmp/c32h2-precommit/inspection.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['binaries','knownNonSecretFixtures']},indent=2));print('binary inventory:');print('\n'.join(x['path'] for x in binary))
