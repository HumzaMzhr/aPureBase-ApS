import {normalizeEmail,validEmail} from './normalize';
import type {ContactEmail,ContactEmailResolver,ContactScope} from './types';

export function boundedRecords(raw:readonly ContactEmail[],scope:ContactScope):ContactEmail[] {
 if(!Array.isArray(raw)||raw.length>3)throw new Error('Bounded contact result required');
 return raw.map(r=>{
  if(!r||r.contactId!==scope.contactId||!r.recordVersion||!r.sourceRecordId||!validEmail(r.email)||r.email!==normalizeEmail(r.email).value)throw new Error('Invalid scoped contact record');
  return {contactId:r.contactId,email:r.email,recordVersion:r.recordVersion,sourceRecordId:r.sourceRecordId};
 });
}
/** Exact fixture IDs only. No fuzzy/global search or production data is bundled. */
export class FixtureContactEmailResolver implements ContactEmailResolver {
 private readonly records:readonly ContactEmail[];
 constructor(records:readonly ContactEmail[]){
  if(records.some(r=>!r.contactId.startsWith('synthetic:')||!r.email.endsWith('.example')))throw new Error('Synthetic reserved-domain records only');
  this.records=structuredClone(records);
 }
 async resolveCandidates(scope:ContactScope,signal:AbortSignal){
  signal.throwIfAborted();
  if(scope.source!=='SYNTHETIC_FIXTURE'||!scope.mappingEvidenceId.startsWith('synthetic:'))throw new Error('Independent synthetic identity mapping required');
  return boundedRecords(this.records.filter(r=>r.contactId===scope.contactId),scope);
 }
}
