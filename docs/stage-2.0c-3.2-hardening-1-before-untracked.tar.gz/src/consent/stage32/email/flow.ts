import type {ConsentSession} from '../../session';
import type {ConsentSnapshot,PlaybackRecord,Transcript} from '../../types';
import type {LocalPlaybackPort} from '../../approved/localPlayback';
import {eligibleRecipient} from '../../authority';
import {ConservativeDanishClassifier,explicitAffirmative} from '../../classifier';
import {currentCatalog} from '../../corrections/assets';
import {qaResponse,retestDefinition} from '../../corrections/retest';
import {EmailAudit} from './audit';
import {reconstructEmail} from './reconstruct';
import {resolveEmail} from './candidateResolver';
import type {ContactEmailResolver,ContactScope,EmailReconciliationPort,EmailTurn,ParsedEmail,Resolution} from './types';

export function hasReviewedConsent(s:ConsentSnapshot){
 const decision=s.decision,t=s.turns.find(t=>t.id===decision?.turnId),q=t?.consent.question,p=s.playbacks.find(p=>p.playbackId===q?.instanceId);
 return !!(decision?.classification==='YES'&&decision.recipientRevision===s.recipientRevision&&eligibleRecipient(s)&&!s.doNotContactRequested&&!['HUMAN_TAKEOVER','END_SUCCESS','END_REFUSED','END_OTHER'].includes(s.state)&&t?.review?.classification==='YES'&&t.review.reason.trim()&&t.consent.eligibleYes&&t.consent.recipient.recipientRevision===s.recipientRevision&&q?.scope===retestDefinition.consentScope&&q.recipientType===s.recipientType&&q.recipientRevision===s.recipientRevision&&p?.state==='COMPLETED'&&p.mode==='local-prerecorded'&&p.completionSource==='VERIFIED_OUTPUT_ADAPTER'&&p.outputProof?.startsWith('web-audio-source-ended:'+p.playbackId+':')&&p.completedAt===q.completedAt&&p.textHash===q.textHash&&p.phraseVersion===q.responseVersion&&p.phraseId===q.responseId&&decision.questionInstanceId===q.instanceId&&t.transcript.answerPlaybackId===q.instanceId&&t.transcript.final&&t.transcript.source==='provider'&&t.transcript.id.startsWith('mic:')&&explicitAffirmative(t.transcript.text)&&t.transcript.speechStartedAt!==undefined&&t.transcript.speechStartedAt>q.completedAt&&t.transcript.observedAt>=t.transcript.speechStartedAt);
}
type Attempt={id:string;turn:EmailTurn;parsed:ParsedEmail;resolution:Resolution;correctionOf?:string};
type Window={id:string;completedAt:number;revision:number;kind:'ADDRESS'|'CONFIRM';attemptId?:string;consumed:boolean};
export type EmailFlowState='IDLE'|'LISTENING'|'RESOLVING'|'CONFIRM_REQUIRED'|'CLARIFICATION_REQUIRED'|'OPERATOR_REVIEW'|'HUMAN_TAKEOVER'|'CONFIRMED_LOCAL_CANDIDATE';

/** Candidate-only adjunct to the unchanged consent engine. Never writes its consent/email/handoff. */
export class EmailAcquisition {
 readonly audit:EmailAudit;
 private state:EmailFlowState='IDLE';private scope?:ContactScope;private window?:Window;private attempt?:Attempt;
 private confirmation?:{turn:EmailTurn;candidate:string};private seen=new Set<string>();
 private onsets=new Map<string,{onset?:number;owner?:string;revision:number;generation:number}>();
 private generation=0;private abort?:AbortController;private playback?:PlaybackRecord;private correctionOf?:string;
 constructor(private session:ConsentSession,private resolver:ContactEmailResolver,private player:LocalPlaybackPort,private model?:EmailReconciliationPort,private now:()=>number=()=>performance.now(),private forwardControl:(turn:Transcript)=>void=turn=>session.receive(turn)){this.audit=new EmailAudit(now);}
 snapshot(){return structuredClone({state:this.state,attempt:this.attempt,confirmation:this.confirmation,window:this.window,playback:this.playback,savingEnabled:false,sourceAudioStored:false,characterReadback:'DIAGNOSTIC_COMPARISON_ONLY',productionReady:false});}
 private current(){const s=this.session.snapshot();return hasReviewedConsent(s)&&this.scope?.callId===s.callId&&this.scope.recipientRevision===s.recipientRevision;}
 open(scope:ContactScope){
  const s=this.session.snapshot(),p=s.playbacks.at(-1),a=currentCatalog().find(a=>a.phraseId==='email-request');
  if(!hasReviewedConsent(s)||scope.callId!==s.callId||scope.recipientRevision!==s.recipientRevision||!scope.contactId||!scope.mappingEvidenceId||!p||!a||p.phraseId!=='email-request'||p.state!=='COMPLETED'||p.mode!=='local-prerecorded'||p.completionSource!=='VERIFIED_OUTPUT_ADAPTER'||p.completedAt===null||p.assetHash!==a.assetHash||p.textHash!==a.textHash||p.recipientRevision!==s.recipientRevision)throw new Error('Current reviewed scoped consent, independent contact mapping and completed email request required');
  this.invalidate('NEW_ADDRESS_WINDOW');this.scope=structuredClone(scope);this.window={id:p.playbackId,completedAt:p.completedAt,revision:s.recipientRevision,kind:'ADDRESS',consumed:false};this.state='LISTENING';
  this.audit.append('email.request_opened',{scope,playback:p,consentTurnId:s.decision!.turnId,canonicalText:a.text});
 }
 owner(){if(!this.current())return undefined;return this.playback&&['QUEUED','PLAYING'].includes(this.playback.state)?this.playback.playbackId:this.window&&!this.window.consumed?this.window.id:undefined;}
 invalidate(reason:string){this.generation++;this.abort?.abort();this.abort=undefined;this.window=undefined;this.confirmation=undefined;if(this.playback&&['QUEUED','PLAYING'].includes(this.playback.state)){this.playback.state='INTERRUPTED';this.player.cancel();}this.state='OPERATOR_REVIEW';this.audit.append('email.invalidated',{reason,attemptId:this.attempt?.id});}
 operatorReview(reviewer:string,reason:string,proposedValue?:string){this.audit.append('email.operator_review',{reviewer,reason,proposedValue,authorizedSave:false});this.invalidate('OPERATOR_REVIEW_CANNOT_OVERRIDE_RECIPIENT_EVIDENCE');}
 private deny(reason:string){this.audit.append('email.evidence_rejected',{reason});return false;}
 /** Adapter must forward the original Danish transcript, not normalized text. */
 async receive(input:EmailTurn):Promise<boolean>{
  this.audit.append('email.asr',{transcript:input,endpointOwner:input.answerPlaybackId??null,revision:input.recipientRevision});
  if(!this.onsets.has(input.id))this.onsets.set(input.id,{onset:input.speechStartedAt,owner:input.answerPlaybackId,revision:input.recipientRevision,generation:this.generation});
  const boundary=this.onsets.get(input.id)!;
  if(!input.final){if(this.playback&&['QUEUED','PLAYING'].includes(this.playback.state))this.invalidate('BARGE_IN');return false;}
  if(this.seen.has(input.id))return this.deny('DUPLICATE_FINAL');this.seen.add(input.id);
  const turn:EmailTurn={...structuredClone(input),speechStartedAt:boundary.onset,answerPlaybackId:boundary.owner,recipientRevision:boundary.revision};
  const intent=new ConservativeDanishClassifier().classify(turn).intent;
  if(['REQUEST_HUMAN','WITHDRAWAL','STOP_CONTACT','AUTHORITY_DENIED','WRONG_PERSON','RECEPTIONIST','RIGHT_PERSON','AUTHORITY_CLAIMED','INTERMEDIARY_OFFER'].includes(intent)){
   this.invalidate(intent);this.state='HUMAN_TAKEOVER';this.forwardControl(turn);this.audit.append('email.control_forwarded',{intent});return false;
  }
  const w=this.window;
  if(!this.current()){this.invalidate('CONSENT_OR_IDENTITY_STALE');return false;}
  if(w?.consumed&&turn.answerPlaybackId===w.id&&boundary.generation===this.generation){this.invalidate('NEW_FINAL_AFTER_CONSUMED_WINDOW');this.state='CLARIFICATION_REQUIRED';return false;}
  if(!w||w.consumed||boundary.generation!==this.generation||turn.source!=='provider'||!turn.id.startsWith('mic:')||turn.answerPlaybackId!==w.id||turn.recipientRevision!==w.revision||turn.speechStartedAt===undefined||!Number.isFinite(turn.speechStartedAt)||!Number.isFinite(turn.observedAt)||turn.speechStartedAt<=w.completedAt||turn.observedAt<turn.speechStartedAt||turn.observedAt>this.now())return this.deny('UNOWNED_STALE_OR_PRE_COMPLETION_FINAL');
  w.consumed=true;
  if(w.kind==='CONFIRM'&&(explicitAffirmative(turn.text)||intent==='EMAIL_CONFIRMED')){
   const attempt=this.attempt;
   if(!attempt||attempt.id!==w.attemptId||attempt.resolution.classification!=='EXACT_VERIFIED_MATCH')return this.deny('NO_EXACT_CONFIRMATION_CANDIDATE');
   const generation=this.generation;this.abort=new AbortController();
   const checked=await resolveEmail(attempt.parsed,this.scope!,this.resolver,undefined,this.abort.signal).catch(()=>null);
   if(generation!==this.generation||!this.current())return this.deny('STALE_CONFIRMATION_LOOKUP');
   if(!checked||checked.classification!=='EXACT_VERIFIED_MATCH'||checked.selected!==attempt.resolution.selected||JSON.stringify(checked.databaseCandidates)!==JSON.stringify(attempt.resolution.databaseCandidates)){this.invalidate('CONTACT_RECORD_CHANGED_OR_UNAVAILABLE');return false;}
   this.confirmation={turn,candidate:checked.selected!};this.state='CONFIRMED_LOCAL_CANDIDATE';this.audit.append('email.recipient_confirmed',{attemptId:attempt.id,turn,candidate:checked.selected,savingEnabled:false});return true;
  }
  if(w.kind==='CONFIRM'&&/^(nej\b|no\b|adressen er forkert|e-mailadressen er forkert)/iu.test(turn.text.trim())){
   this.correctionOf=this.attempt?.id;this.invalidate('RECIPIENT_DENIED_EMAIL');this.state='CLARIFICATION_REQUIRED';this.audit.append('email.correction_required',{sourceTurnId:turn.id,correctionOf:this.correctionOf});return false;
  }
  this.abort?.abort();const generation=++this.generation;this.abort=new AbortController();this.state='RESOLVING';
  const parsed=reconstructEmail(turn.text);this.audit.append('email.parsed',{sourceTurnId:turn.id,parsed});
  const resolution=await resolveEmail(parsed,this.scope!,this.resolver,this.model,this.abort.signal).catch(()=>null);
  if(generation!==this.generation||!this.current())return this.deny('STALE_RESOLUTION');
  if(!resolution){this.invalidate('RESOLUTION_CANCELLED');return false;}
  this.attempt={id:turn.id,turn,parsed,resolution,correctionOf:this.correctionOf??(w.kind==='CONFIRM'?w.attemptId:undefined)};this.correctionOf=undefined;
  this.state=resolution.action==='CONFIRM'?'CONFIRM_REQUIRED':resolution.action;
  this.audit.append('email.resolved',this.attempt);return true;
 }
 /** Unambiguous exact speech only. HIGH requires re-spelling/clarification, not a generic yes. */
 async confirmPrompt(){
  if(!this.current()||this.state!=='CONFIRM_REQUIRED'||this.attempt?.resolution.classification!=='EXACT_VERIFIED_MATCH'){this.audit.append('email.confirmation_blocked',{reason:'Concise question cannot disambiguate unspoken inferred characters; request fresh address or operator review'});throw new Error('Exact spoken reconstruction required; high confidence needs explicit disambiguation');}
  const a=currentCatalog().find(a=>a.phraseId==='email-confirmation-question')!;
  const generation=this.generation,attempt=this.attempt,s=this.session.snapshot();
  const p:PlaybackRecord={playbackId:crypto.randomUUID(),callId:s.callId,phraseId:a.phraseId,phraseVersion:a.wordingVersion,assetId:a.path,assetHash:a.assetHash,textHash:a.textHash,state:'QUEUED',mode:'local-prerecorded',queuedAt:this.now(),startedAt:null,completedAt:null,interruptedAt:null,failedAt:null,completionSource:null,recipientRevision:s.recipientRevision,answerConsumed:false};
  this.playback=p;this.window=undefined;this.audit.append('email.confirmation_queued',{attemptId:attempt.id,selected:attempt.resolution.selected,record:p});
  try{await this.player.play(qaResponse(a),structuredClone(p),event=>{
   this.audit.append('email.output',event);
   if(generation!==this.generation||!this.current()||this.playback!==p||!['QUEUED','PLAYING'].includes(p.state)||event.playbackId!==p.playbackId||event.callId!==p.callId||event.phraseId!==p.phraseId||event.phraseVersion!==p.phraseVersion||event.assetHash!==p.assetHash||event.textHash!==p.textHash||event.recipientRevision!==p.recipientRevision)return;
   if(event.action==='start'){p.state='PLAYING';p.startedAt=this.now();}
   if(event.action==='complete'&&p.state==='PLAYING'&&event.outputProof?.startsWith('web-audio-source-ended:'+p.playbackId+':')&&(!event.gain||!event.gain.clippingEvents)){
    p.state='COMPLETED';p.completedAt=this.now();p.completionSource='VERIFIED_OUTPUT_ADAPTER';p.outputProof=event.outputProof;p.gain=event.gain;
    this.window={id:p.playbackId,completedAt:p.completedAt,revision:p.recipientRevision,kind:'CONFIRM',attemptId:attempt.id,consumed:false};
   }else if(['interrupt','fail'].includes(event.action))this.invalidate('CONFIRMATION_OUTPUT_'+event.action);
  });}catch(error){this.invalidate('CONFIRMATION_OUTPUT_FAILED');throw error;}
  // A resolved promise with no source-ended event is never completion proof.
  if(p.state!=='COMPLETED'&&generation===this.generation)this.invalidate('NO_COMPLETED_OUTPUT_PROOF');
 }
 export(){return {...this.snapshot(),...this.audit.export(),stage:'2.0C-3.2',status:'NOT_ACCEPTED',downstreamHandoffEnabled:false,telephoneVerified:false};}
}

/** Route an email turn only after the host opened this flow from the real consent session. */
export function emailTurn(raw:Transcript,recipientRevision:number):EmailTurn{return {...structuredClone(raw),recipientRevision};}
