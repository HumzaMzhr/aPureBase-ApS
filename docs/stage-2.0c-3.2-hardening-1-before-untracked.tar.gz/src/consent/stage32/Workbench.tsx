import {useState} from 'react';
import {reconstructEmail} from './email/reconstruct';
import {resolveEmail} from './email/candidateResolver';
import {FixtureContactEmailResolver} from './email/databaseResolver';
import {pronunciationRegressions,providerCapabilities} from './speech/plans';

export function Workbench(){
 const [text,setText]=useState('anna snabel-a clinic punktum example'),[result,setResult]=useState<{parsed:ReturnType<typeof reconstructEmail>;resolved:Awaited<ReturnType<typeof resolveEmail>>;consentEvidence:false;savingEnabled:false}|null>(null);
 async function inspect(){const parsed=reconstructEmail(text);const resolved=await resolveEmail(parsed,{callId:'synthetic:workbench',recipientRevision:1,contactId:'synthetic:clinic',mappingEvidenceId:'synthetic:manual-fixture',source:'SYNTHETIC_FIXTURE'},new FixtureContactEmailResolver([{contactId:'synthetic:clinic',email:'anna@clinic.example',recordVersion:'1',sourceRecordId:'synthetic:record'}]));setResult({parsed,resolved,consentEvidence:false,savingEnabled:false});}
 return <main style={{maxWidth:980,margin:'40px auto',padding:24,fontFamily:'system-ui',color:'#183536',background:'#fafbf8'}}>
  <p>LOCAL · OFFLINE · SYNTHETIC FIXTURES</p><h1>Danish speech + email resolution</h1><h2>Stage 2.0C-3.2 · NOT ACCEPTED</h2>
  <p>This workbench inspects deterministic text evidence. It does not capture a microphone, call providers, play audio, grant consent or save contact data. Use synthetic values only.</p>
  <label htmlFor="email-asr">Literal Danish ASR text</label><textarea id="email-asr" rows={3} style={{display:'block',width:'100%',margin:'12px 0',font:'inherit'}} value={text} onChange={e=>setText(e.target.value)}/>
  <button type="button" onClick={()=>void inspect()}>Inspect synthetic email evidence</button>
  <p>Fixture scope: independently mapped synthetic clinic → anna@clinic.example. Matching is exact and bounded. Every class still requires recipient confirmation or review; saving is disabled.</p>
  {result!==null&&<section style={{padding:20,background:'#e9f0ed'}}><h2>{result.resolved.classification}</h2><p>Candidate: {result.resolved.selected??'Unresolved'} · Action: {result.resolved.action} · Consent evidence: false · Saving: disabled</p><details><summary>Inspect raw tokens, transformations and bounded evidence</summary><pre style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{JSON.stringify(result,null,2)}</pre></details></section>}
  <h2>Pronunciation review remains pending</h2><p>Isabella · eleven_flash_v2_5 · speed 0.95 · calibrated gain unchanged. Canonical wording is the audit authority. No new audio has been generated.</p>
  <p>Mandatory regression: <strong>{pronunciationRegressions[0].phraseId} / {pronunciationRegressions[0].canonicalSpan}</strong>. Approximate listening descriptions remain review metadata, never misspelled production wording.</p>
  <p>Pinned-model Danish dictionary phonemes supported: {String(providerCapabilities.danishDictionaryPhonemes)}. Punctuation and sentence-boundary variants await authorization, generation and native listening.</p>
  <p>Acceptance targets: all consent-critical units reviewed, ≥95% inventory accepted, every mandatory regression PASS. Automated checks cannot prove natural Danish pronunciation.</p>
  <p><a href="/consent-call?stage=2.0c31">Preserved C-3.1 human retest workspace</a> — its character readback remains historical/diagnostic. The opt-in C-3.2 session adapter uses clinic-spoken email; high-confidence uncertainty requires explicit disambiguation or operator review.</p>
 </main>;
}
