import {PhysicalRecognition,type SourceAudit} from '../acceptance/recognition';
import {ASRPreflight} from '../corrections/preflight';
import {EmailASRDiagnostics} from './diagnostics';
import type {StructuredEmailSession} from './session';

/** Construction is inert. The existing bridge's start() remains a separately authorized
 * manual microphone/provider action. No recognition settings or VAD thresholds change.
 */
export function prepareC32Recognition(session:StructuredEmailSession,preflight:ASRPreflight,diagnostics:EmailASRDiagnostics,notify:(e:SourceAudit)=>void,failed:(error:Error)=>void,now=()=>performance.now(),factory?:ConstructorParameters<typeof PhysicalRecognition>[4],microphone?:ConstructorParameters<typeof PhysicalRecognition>[5],spokenTest=()=> ''){
 return new PhysicalRecognition(session,e=>{diagnostics.observe(e);preflight.observe(e,spokenTest());session.structuredEmail.audit.append('email.source_lifecycle',e);notify(e);},error=>{session.structuredEmail.invalidate('ASR_FAILED');failed(error);},now,factory,microphone);
}
