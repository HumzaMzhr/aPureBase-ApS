import {currentCatalog} from '../corrections/assets';

/** Content durations, not measured physical call timing. New audio is ungenerated. */
export function durationModel(){
 const catalog=currentCatalog(),staticIds=['opening','purpose','consent-question','email-request','email-confirmation-question','success-close'];
 const units=staticIds.map(id=>{const a=catalog.find(a=>a.phraseId===id&&!('binding'in a));if(!a)throw new Error('Missing static duration '+id);return {phraseId:id,audioHash:a.assetHash,seconds:a.duration};});
 const totalStatic=units.reduce((a,b)=>a+b.seconds,0),emails=catalog.filter(a=>'binding'in a&&a.binding.slot.kind==='EMAIL');
 const prefix=catalog.find(a=>a.phraseId==='email-readback-intro'&&!('binding'in a))!;
 const assumptions={recipientResponseSeconds:[12,25],transitionSeconds:[1,4],operatorReviewSeconds:[2,6],resolverBudgetSeconds:[0,.25]};
 return {kind:'OFFLINE_CONTENT_AND_ASSUMPTION_MODEL_NOT_PHYSICAL_TELEPHONE_TIMING',targetOrdinarySuccessSeconds:[30,90],preferredSeconds:[30,60],path:'Verified target HCP, reviewed scoped consent, exact spoken email + unique exact scoped record, concise owned confirmation',staticUnits:units,staticAudioSeconds:totalStatic,dynamicAudioSeconds:0,assumptions,providerNetworkSeconds:null,unknownUnmodeled:['Live ASR availability/endpoint latency','Real CRM lookup/network latency (adapter absent)','Human decision/delivery overlap','Physical output gaps and barge-in','Arbitrary-name units','New pronunciation variants and joins'],subtotalExcludingUnknownSeconds:[totalStatic+12+1+2,totalStatic+25+4+6+.25],legacyCharacterReadbackComparisons:emails.map(a=>({audioHash:a.assetHash,legacyDynamicSeconds:a.duration,legacyPrefixSeconds:prefix.duration,modeledAudioSecondsRemoved:a.duration+prefix.duration,measuredPhysicalSavingSeconds:null})),highConfidencePath:'Explicit address disambiguation or operator review: no duration bound claimed',refusalBusyPaths:'Existing short exits preserved; no padding or minimum-duration constraint applied',newSynthesisVariantDurations:null,physicalVerified:false};
}
