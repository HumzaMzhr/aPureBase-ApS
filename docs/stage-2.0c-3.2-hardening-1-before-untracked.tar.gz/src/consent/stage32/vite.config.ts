import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {resolve} from 'node:path';
export default defineConfig({plugins:[react()],build:{rollupOptions:{input:resolve(process.cwd(),'stage20c32.html')}}});
