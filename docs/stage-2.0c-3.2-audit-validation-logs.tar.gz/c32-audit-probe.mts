import {writeFile} from 'node:fs/promises';
import {StructuredEmailSession} from '/Users/humzamazhar/Documents/ChatGPT/aPureBase ApS/src/consent/stage32/session.ts';
import {currentCatalog,prepareCorrection} from '/Users/humzamazhar/Documents/ChatGPT/aPureBase ApS/src/consent/corrections/assets.ts';
import {parseEmailEvidence} from '/Users/humzamazhar/Documents/ChatGPT/aPureBase ApS/src/consent/stage32/hardening/parser.ts';
import {resolveEvidence} from '/Users/humzamazhar/Documents/ChatGPT/aPureBase ApS/src/consent/stage32/hardening/resolution.ts';
import {HumanReviewEvidence} from '/Users/humzamazhar/Documents/ChatGPT/aPureBase ApS/src/consent/stage32/hardening/review.ts';
import {boundedRecords} from '/Users/humzamazhar/Documents/ChatGPT/aPureBase ApS/src/consent/stage32/email/databaseResolver.ts';
let networkAttempts=0;globalThis.fetch=async()=>{networkAttempts++;throw new Error('AUDIT_NETWORK_FORBIDDEN');};
async function probeSession(hardened:boolean){
 let time=100,seq=0;const scope={callId:'synthetic:audit',recipientRevision:1,contactId:'synthetic:audit',mappingEvidenceId:'synthetic:map',source:'SYNTHETIC_FIXTURE' as const};
 const records=[{contactId:scope.contactId,email:'anna@clinic.example',recordVersion:'1',sourceRecordId:'synthetic:row'}];
 const player={prepare:prepareCorrection,register:()=>{},cancel:()=>{},play:async(r:any,p:any,emit:any)=>{const a=currentCatalog().find(a=>a.assetHash===r.audio.sha256)!;const event={callId:p.callId,playbackId:p.playbackId,phraseId:r.id,phraseVersion:r.version,textHash:a.textHash,assetHash:a.assetHash,recipientRevision:p.recipientRevision};time++;emit({...event,action:'start'});time++;emit({...event,action:'complete',outputProof:'web-audio-source-ended:'+p.playbackId+':AUDIT_MOCK_ONLY'});}};
 const s=new StructuredEmailSession(scope.callId,{now:()=>time,localPlayback:player,dynamicSpeech:player},{resolveCandidates:async()=>records},hardened?{parse:parseEmailEvidence,resolve:resolveEvidence}:{});
 const say=async(text:string)=>{time++;s.receive({id:'mic:audit:'+(++seq),text,source:'provider',final:true,observedAt:time,speechStartedAt:time,answerPlaybackId:s.confirmationPlaybackId()??s.snapshot().activePlaybackId});await s.settled();};
 await s.approvePlayback('opening');s.setRecipient('TARGET_HCP','Synthetic audit only',true);await s.approvePlayback('purpose');await s.approvePlayback('consent-question');await say('Ja');s.reviewConsent(s.snapshot().turns.at(-1)!.id,'YES','Synthetic explicit audit review');s.bindContactScope({...scope,recipientRevision:s.snapshot().recipientRevision});await s.approvePlayback('email-request');await say('anna@clinic.example; anna@clinic.example');const a=s.structuredEmail.snapshot().attempt;return {state:s.structuredEmail.snapshot().state,selected:a?.resolution.selected,parseErrors:a?.parsed.errors,classification:a?.resolution.classification};
}
const result:any={kind:'INDEPENDENT_OFFLINE_AUDIT_PROBES_NOT_PROVIDER_OR_HUMAN_EVIDENCE',defaultSession:await probeSession(false),explicitHardenedSession:await probeSession(true)};
const scope={callId:'synthetic:probe',recipientRevision:1,contactId:'synthetic:probe',mappingEvidenceId:'synthetic:map',source:'SYNTHETIC_FIXTURE' as const};
try{const rows=boundedRecords([{contactId:scope.contactId,email:'anna@clinic.example',recordVersion:{bad:'not a version'},sourceRecordId:{bad:'not an id'}} as never],scope);result.malformedDatabase={rejected:false,recordVersionType:typeof rows[0].recordVersion,sourceRecordIdType:typeof rows[0].sourceRecordId};}catch{result.malformedDatabase={rejected:true};}
const review=new HumanReviewEvidence('SYNTHETIC AUDIT ONLY',{userAgent:'offline audit',language:'da',timeZone:'UTC'});
try{review.microphone({testId:'not-one-of-five',rawTranscript:'SYNTHETIC AUDIT ONLY',latencyMs:null,status:'PASS',comments:'Missing final/materialErrors fields deliberately'} as never);result.incompleteMicrophoneObservation={rejected:false,export:review.export().microphoneTests[0]};}catch{result.incompleteMicrophoneObservation={rejected:true};}
result.networkAttempts=networkAttempts;
await writeFile('/tmp/c32-audit-probe-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
